import sys,os,re,socket,binascii,time,json,random,threading,Queue,pprint,urlparse,smtplib,telnetlib,os.path,hashlib,string,urllib2,glob,sqlite3,urllib,argparse,marshal,base64,requests
from colorama import *
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from Queue import Queue
from time import strftime
from urlparse import urlparse
from urllib2 import urlopen
init()

la7mar  = '\033[91m'
lazra9  = '\033[94m'
la5dhar = '\033[92m'
movv    = '\033[95m'
lasfar  = '\033[93m'
ramadi  = '\033[90m'
blid    = '\033[1m'
star    = '\033[4m'
bigas   = '\033[07m'
bigbbs  = '\033[27m'
hell    = '\033[05m'
saker   = '\033[25m'
labyadh = '\033[00m'
cyan    = '\033[0;96m'

def logo():
        clear = "\x1b[0m"
        colors = [32, 34, 37 ]

        x = """ 
 _____                                ___   __      _       _ _            
|_   _|                              (_) \ / /     | |     (_) |           
  | |  ______ _ _ __   __ _ _ __ ___  _ \ V / _ __ | | ___  _| |_ ___ _ __ 
  | | |_  / _` | '_ \ / _` | '_ ` _ \| | > < | '_ \| |/ _ \| | __/ _ \ '__|
 _| |_ / / (_| | | | | (_| | | | | | | |/ . \| |_) | | (_) | | ||  __/ |   
|_____/___\__,_|_| |_|\__,_|_| |_| |_|_/_/ \_\ .__/|_|\___/|_|\__\___|_|   
                                             | |                             
 [+] IzanamiXploiter V 3.0                   |_|
 [+] Code by ./H1RUK4                     
 [+] Telegram : https://t.me/hiruka404

			                  """
        for N, line in enumerate(x.split("\n")):
            sys.stdout.write("\x1b[1;%dm%s%s\n" % (random.choice(colors), line, clear))
            time.sleep(0.05)


logo()

choice=raw_input('[+] Run Izanami Bot > [y] : ')
if choice=='y':
  print(''' 
[+] Install Module and RUN > [OK]''')
  sellemi=raw_input('[+] root@hiruka~# ')
  flo=raw_input('[+] Input Your List : ')
  if sellemi=='OK':
   kk=' -t 999999999999'
   os.system('perl Tools/bot/bot.pl -u '+flo+kk)
  elif sellemi=='OK':
   if system() == 'Windows':
    os.system('cd C:\Perl64 && cpan Parallel::ForkManager')
    kk=' -t 999999999999'
    os.system('perl Tools/bot/bot.pl -u '+flo+kk)
   if system() == 'Linux':
    os.system('sudo apt-get install libparallel-forkmanager-perl ')
    kk=' -t 999999999999'
    os.system('perl Tools/bot/bot.pl -u '+flo+kk)